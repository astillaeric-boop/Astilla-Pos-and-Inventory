package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Emerald POS (Theme 0)
val EmeraldPrimary = Color(0xFF059669)
val EmeraldSecondary = Color(0xFF0D9488)
val EmeraldTertiary = Color(0xFF10B981)
val EmeraldPrimaryDark = Color(0xFF34D399)
val EmeraldSecondaryDark = Color(0xFF2DD4BF)

// Sapphire Pro (Theme 1)
val SapphirePrimary = Color(0xFF2563EB)
val SapphireSecondary = Color(0xFF0284C7)
val SapphireTertiary = Color(0xFF3B82F6)
val SapphirePrimaryDark = Color(0xFF60A5FA)
val SapphireSecondaryDark = Color(0xFF38BDF8)

// Amber Retail (Theme 2)
val AmberPrimary = Color(0xFFD97706)
val AmberSecondary = Color(0xFFB45309)
val AmberTertiary = Color(0xFFF59E0B)
val AmberPrimaryDark = Color(0xFFFBBF24)
val AmberSecondaryDark = Color(0xFFFCD34D)

// Crimson Modern (Theme 3)
val CrimsonPrimary = Color(0xFFE11D48)
val CrimsonSecondary = Color(0xFFBE123C)
val CrimsonTertiary = Color(0xFFF43F5E)
val CrimsonPrimaryDark = Color(0xFFFB7185)
val CrimsonSecondaryDark = Color(0xFFFDA4AF)

// Neutrals
val SlateDarkBackground = Color(0xFF0F172A)
val SlateDarkSurface = Color(0xFF1E293B)
val SlateDarkSurfaceVariant = Color(0xFF334155)

val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF1F5F9)
