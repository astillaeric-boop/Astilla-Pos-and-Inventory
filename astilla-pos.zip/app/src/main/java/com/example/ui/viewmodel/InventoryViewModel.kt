package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.entity.AppSettingsEntity
import com.example.data.local.entity.DeliveryEntity
import com.example.data.local.entity.ProductEntity
import com.example.data.repository.PosRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class StockFilter {
    ALL,
    LOW_STOCK,
    OUT_OF_STOCK
}

data class ProductFormState(
    val id: Long = 0L,
    val name: String = "",
    val barcode: String = "",
    val imagePath: String? = null,
    val costPrice: String = "",
    val retailPrice: String = "",
    val stockQuantity: String = ""
)

data class DeliveryFormState(
    val supplierName: String = "",
    val totalCost: String = "",
    val notes: String = "",
    val selectedProductId: Long? = null,
    val addedStockQuantity: String = ""
)

class InventoryViewModel(application: Application) : AndroidViewModel(application) {
    private val database = AppDatabase.getDatabase(application)
    val repository = PosRepository(database)

    val settings: StateFlow<AppSettingsEntity> = repository.appSettings
        .map { it ?: AppSettingsEntity() }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = AppSettingsEntity()
        )

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _stockFilter = MutableStateFlow(StockFilter.ALL)
    val stockFilter: StateFlow<StockFilter> = _stockFilter.asStateFlow()

    val products: StateFlow<List<ProductEntity>> = combine(
        repository.allProducts,
        _searchQuery,
        _stockFilter
    ) { all, query, filter ->
        var list = all
        if (query.isNotBlank()) {
            val q = query.trim().lowercase()
            list = list.filter {
                it.name.lowercase().contains(q) || it.barcode.lowercase().contains(q)
            }
        }
        when (filter) {
            StockFilter.ALL -> list
            StockFilter.LOW_STOCK -> list.filter { it.stockQuantity in 1..10 }
            StockFilter.OUT_OF_STOCK -> list.filter { it.stockQuantity <= 0 }
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val allDeliveries: StateFlow<List<DeliveryEntity>> = repository.allDeliveries
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    private val _isAddProductDialogOpen = MutableStateFlow(false)
    val isAddProductDialogOpen: StateFlow<Boolean> = _isAddProductDialogOpen.asStateFlow()

    private val _productForm = MutableStateFlow(ProductFormState())
    val productForm: StateFlow<ProductFormState> = _productForm.asStateFlow()

    private val _isBarcodeScannerOpen = MutableStateFlow(false)
    val isBarcodeScannerOpen: StateFlow<Boolean> = _isBarcodeScannerOpen.asStateFlow()

    private val _isDeliveryDialogOpen = MutableStateFlow(false)
    val isDeliveryDialogOpen: StateFlow<Boolean> = _isDeliveryDialogOpen.asStateFlow()

    private val _deliveryForm = MutableStateFlow(DeliveryFormState())
    val deliveryForm: StateFlow<DeliveryFormState> = _deliveryForm.asStateFlow()

    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

    fun onSearchQueryChanged(query: String) {
        _searchQuery.value = query
    }

    fun setStockFilter(filter: StockFilter) {
        _stockFilter.value = filter
    }

    fun clearToast() {
        _toastMessage.value = null
    }

    fun openAddProductDialog(productToEdit: ProductEntity? = null) {
        if (productToEdit != null) {
            _productForm.value = ProductFormState(
                id = productToEdit.id,
                name = productToEdit.name,
                barcode = productToEdit.barcode,
                imagePath = productToEdit.imagePath,
                costPrice = productToEdit.costPrice.toString(),
                retailPrice = productToEdit.retailPrice.toString(),
                stockQuantity = productToEdit.stockQuantity.toString()
            )
        } else {
            _productForm.value = ProductFormState()
        }
        _isAddProductDialogOpen.value = true
    }

    fun closeAddProductDialog() {
        _isAddProductDialogOpen.value = false
        _productForm.value = ProductFormState()
    }

    fun updateProductForm(form: ProductFormState) {
        _productForm.value = form
    }

    fun openScannerForBarcode() {
        _isBarcodeScannerOpen.value = true
    }

    fun closeScannerForBarcode() {
        _isBarcodeScannerOpen.value = false
    }

    fun onBarcodeScanned(barcode: String) {
        _productForm.value = _productForm.value.copy(barcode = barcode)
        _isBarcodeScannerOpen.value = false
        _toastMessage.value = "Barcode scanned: $barcode"
    }

    fun setProductImage(imageUri: String?) {
        _productForm.value = _productForm.value.copy(imagePath = imageUri)
    }

    fun saveProduct() {
        val form = _productForm.value
        if (form.name.isBlank()) {
            _toastMessage.value = "Please enter a product name"
            return
        }
        val cost = form.costPrice.toDoubleOrNull() ?: 0.0
        val retail = form.retailPrice.toDoubleOrNull() ?: 0.0
        val stock = form.stockQuantity.toIntOrNull() ?: 0

        viewModelScope.launch {
            val entity = ProductEntity(
                id = form.id,
                name = form.name.trim(),
                barcode = form.barcode.trim(),
                imagePath = form.imagePath,
                costPrice = cost,
                retailPrice = retail,
                stockQuantity = stock
            )
            repository.insertOrUpdateProduct(entity)
            closeAddProductDialog()
            _toastMessage.value = if (form.id == 0L) "Product added" else "Product updated"
        }
    }

    fun deleteProduct(product: ProductEntity) {
        viewModelScope.launch {
            repository.deleteProduct(product)
            _toastMessage.value = "Product removed"
        }
    }

    fun openDeliveryDialog() {
        _deliveryForm.value = DeliveryFormState()
        _isDeliveryDialogOpen.value = true
    }

    fun closeDeliveryDialog() {
        _isDeliveryDialogOpen.value = false
        _deliveryForm.value = DeliveryFormState()
    }

    fun updateDeliveryForm(form: DeliveryFormState) {
        _deliveryForm.value = form
    }

    fun saveDelivery() {
        val form = _deliveryForm.value
        if (form.supplierName.isBlank()) {
            _toastMessage.value = "Please enter supplier name"
            return
        }
        val totalCost = form.totalCost.toDoubleOrNull() ?: 0.0
        val addedStock = form.addedStockQuantity.toIntOrNull() ?: 0

        viewModelScope.launch {
            val delivery = DeliveryEntity(
                supplierName = form.supplierName.trim(),
                totalCost = totalCost,
                notes = form.notes.trim()
            )
            val updatedProducts = if (form.selectedProductId != null && addedStock > 0) {
                listOf(Pair(form.selectedProductId, addedStock))
            } else {
                emptyList()
            }
            repository.logDelivery(delivery, updatedProducts)
            closeDeliveryDialog()
            _toastMessage.value = "Delivery logged successfully"
        }
    }
}
