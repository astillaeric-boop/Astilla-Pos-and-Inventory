package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.entity.AppSettingsEntity
import com.example.data.local.entity.ProductEntity
import com.example.data.local.entity.SaleEntity
import com.example.data.local.entity.SaleItemEntity
import com.example.data.local.entity.SaleWithItems
import com.example.data.repository.PosRepository
import com.example.util.SoundManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class CartItem(
    val product: ProductEntity,
    val quantity: Int
)

data class PosUiState(
    val cartItems: List<CartItem> = emptyList(),
    val subtotal: Double = 0.0,
    val taxAmount: Double = 0.0,
    val totalAmount: Double = 0.0,
    val isScannerOpen: Boolean = false,
    val isCartSheetOpen: Boolean = false,
    val selectedPaymentType: String = "Cash",
    val lastCompletedSale: SaleWithItems? = null,
    val isReceiptDialogOpen: Boolean = false,
    val toastMessage: String? = null
)

class PosViewModel(application: Application) : AndroidViewModel(application) {
    private val database = AppDatabase.getDatabase(application)
    val repository = PosRepository(database)
    val soundManager = SoundManager()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    val settings: StateFlow<AppSettingsEntity> = repository.appSettings
        .map { it ?: AppSettingsEntity() }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = AppSettingsEntity()
        )

    val products: StateFlow<List<ProductEntity>> = combine(
        repository.allProducts,
        _searchQuery
    ) { all, query ->
        if (query.isBlank()) {
            all
        } else {
            val q = query.trim().lowercase()
            all.filter {
                it.name.lowercase().contains(q) || it.barcode.lowercase().contains(q)
            }
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    private val _uiState = MutableStateFlow(PosUiState())
    val uiState: StateFlow<PosUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            repository.seedDemoDataIfEmpty()
        }
    }

    fun onSearchQueryChanged(query: String) {
        _searchQuery.value = query
    }

    fun openScanner() {
        _uiState.value = _uiState.value.copy(isScannerOpen = true)
    }

    fun closeScanner() {
        _uiState.value = _uiState.value.copy(isScannerOpen = false)
    }

    fun openCartSheet() {
        _uiState.value = _uiState.value.copy(isCartSheetOpen = true)
    }

    fun closeCartSheet() {
        _uiState.value = _uiState.value.copy(isCartSheetOpen = false)
    }

    fun setPaymentType(paymentType: String) {
        _uiState.value = _uiState.value.copy(selectedPaymentType = paymentType)
    }

    fun clearToastMessage() {
        _uiState.value = _uiState.value.copy(toastMessage = null)
    }

    fun onBarcodeScanned(barcode: String) {
        viewModelScope.launch {
            val product = repository.getProductByBarcode(barcode.trim())
            val soundEnabled = settings.value.soundEnabled
            if (product != null) {
                soundManager.playScanBeep(soundEnabled)
                addToCart(product)
                _uiState.value = _uiState.value.copy(
                    toastMessage = "Added: ${product.name}",
                    isScannerOpen = false // Dismiss scanner after scan or leave open
                )
            } else {
                soundManager.playErrorTone(soundEnabled)
                _uiState.value = _uiState.value.copy(
                    toastMessage = "Unrecognized Barcode: $barcode"
                )
            }
        }
    }

    fun addToCart(product: ProductEntity) {
        val currentItems = _uiState.value.cartItems.toMutableList()
        val index = currentItems.indexOfFirst { it.product.id == product.id }
        if (index >= 0) {
            val existing = currentItems[index]
            currentItems[index] = existing.copy(quantity = existing.quantity + 1)
        } else {
            currentItems.add(CartItem(product = product, quantity = 1))
        }
        recalculateTotals(currentItems)
    }

    fun decrementQuantity(productId: Long) {
        val currentItems = _uiState.value.cartItems.toMutableList()
        val index = currentItems.indexOfFirst { it.product.id == productId }
        if (index >= 0) {
            val existing = currentItems[index]
            if (existing.quantity > 1) {
                currentItems[index] = existing.copy(quantity = existing.quantity - 1)
            } else {
                currentItems.removeAt(index)
            }
            recalculateTotals(currentItems)
        }
    }

    fun removeFromCart(productId: Long) {
        val currentItems = _uiState.value.cartItems.filter { it.product.id != productId }
        recalculateTotals(currentItems)
    }

    fun clearCart() {
        recalculateTotals(emptyList())
    }

    private fun recalculateTotals(cartItems: List<CartItem>) {
        val subtotal = cartItems.sumOf { it.product.retailPrice * it.quantity }
        val currentSettings = settings.value
        val taxAmount = if (currentSettings.taxEnabled) {
            subtotal * (currentSettings.taxRate / 100.0)
        } else {
            0.0
        }
        val total = subtotal + taxAmount

        _uiState.value = _uiState.value.copy(
            cartItems = cartItems,
            subtotal = subtotal,
            taxAmount = taxAmount,
            totalAmount = total
        )
    }

    fun checkout() {
        val currentState = _uiState.value
        if (currentState.cartItems.isEmpty()) return

        viewModelScope.launch {
            val saleEntity = SaleEntity(
                timestamp = System.currentTimeMillis(),
                totalAmount = currentState.totalAmount,
                taxAmount = currentState.taxAmount,
                paymentType = currentState.selectedPaymentType,
                isSynced = false
            )

            val saleItems = currentState.cartItems.map { cartItem ->
                SaleItemEntity(
                    saleId = 0L,
                    productId = cartItem.product.id,
                    productName = cartItem.product.name,
                    quantity = cartItem.quantity,
                    unitCost = cartItem.product.costPrice,
                    unitPrice = cartItem.product.retailPrice
                )
            }

            val saleId = repository.checkoutSale(saleEntity, saleItems)
            val completedSale = SaleWithItems(
                sale = saleEntity.copy(id = saleId),
                items = saleItems.map { it.copy(saleId = saleId) }
            )

            soundManager.playSuccessCheckout(settings.value.soundEnabled)

            _uiState.value = _uiState.value.copy(
                cartItems = emptyList(),
                subtotal = 0.0,
                taxAmount = 0.0,
                totalAmount = 0.0,
                isCartSheetOpen = false,
                lastCompletedSale = completedSale,
                isReceiptDialogOpen = true,
                toastMessage = "Checkout completed successfully!"
            )
        }
    }

    fun dismissReceiptDialog() {
        _uiState.value = _uiState.value.copy(
            isReceiptDialogOpen = false,
            lastCompletedSale = null
        )
    }

    override fun onCleared() {
        super.onCleared()
        soundManager.release()
    }
}
