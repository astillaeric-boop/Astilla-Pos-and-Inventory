package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.entity.AppSettingsEntity
import com.example.data.repository.PosRepository
import com.example.data.sync.GoogleSheetSyncWorker
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SettingsViewModel(application: Application) : AndroidViewModel(application) {
    private val database = AppDatabase.getDatabase(application)
    val repository = PosRepository(database)

    val settings: StateFlow<AppSettingsEntity> = repository.appSettings
        .map { it ?: AppSettingsEntity() }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = AppSettingsEntity()
        )

    private val _isSyncing = MutableStateFlow(false)
    val isSyncing: StateFlow<Boolean> = _isSyncing.asStateFlow()

    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

    private val _showScriptDialog = MutableStateFlow(false)
    val showScriptDialog: StateFlow<Boolean> = _showScriptDialog.asStateFlow()

    private val _showResetDialog = MutableStateFlow(false)
    val showResetDialog: StateFlow<Boolean> = _showResetDialog.asStateFlow()

    private val _showSecondResetConfirm = MutableStateFlow(false)
    val showSecondResetConfirm: StateFlow<Boolean> = _showSecondResetConfirm.asStateFlow()

    init {
        // Schedule periodic sync via WorkManager
        GoogleSheetSyncWorker.schedulePeriodicSync(application)
    }

    fun clearToast() {
        _toastMessage.value = null
    }

    fun updateStoreName(name: String) {
        val current = settings.value
        viewModelScope.launch {
            repository.saveSettings(current.copy(storeName = name))
        }
    }

    fun updateCurrencySymbol(symbol: String) {
        val current = settings.value
        viewModelScope.launch {
            repository.saveSettings(current.copy(currencySymbol = symbol))
        }
    }

    fun toggleTax(enabled: Boolean) {
        val current = settings.value
        viewModelScope.launch {
            repository.saveSettings(current.copy(taxEnabled = enabled))
        }
    }

    fun updateTaxRate(rate: Float) {
        val current = settings.value
        viewModelScope.launch {
            repository.saveSettings(current.copy(taxRate = rate))
        }
    }

    fun toggleSound(enabled: Boolean) {
        val current = settings.value
        viewModelScope.launch {
            repository.saveSettings(current.copy(soundEnabled = enabled))
        }
    }

    fun updateTheme(themeIndex: Int) {
        val current = settings.value
        viewModelScope.launch {
            repository.saveSettings(current.copy(themeColor = themeIndex))
        }
    }

    fun updateGoogleSheetLink(url: String) {
        val current = settings.value
        viewModelScope.launch {
            repository.saveSettings(current.copy(googleSheetLink = url))
        }
    }

    fun triggerSyncNow() {
        _isSyncing.value = true
        GoogleSheetSyncWorker.triggerImmediateSync(getApplication())
        viewModelScope.launch {
            kotlinx.coroutines.delay(1200)
            _isSyncing.value = false
            _toastMessage.value = "Sync job dispatched to WorkManager"
        }
    }

    fun openScriptDialog() {
        _showScriptDialog.value = true
    }

    fun closeScriptDialog() {
        _showScriptDialog.value = false
    }

    fun openResetDialog() {
        _showResetDialog.value = true
    }

    fun closeResetDialog() {
        _showResetDialog.value = false
        _showSecondResetConfirm.value = false
    }

    fun proceedToSecondConfirm() {
        _showResetDialog.value = false
        _showSecondResetConfirm.value = true
    }

    fun executeDatabaseReset() {
        viewModelScope.launch {
            repository.resetDatabase()
            _showSecondResetConfirm.value = false
            _toastMessage.value = "Database cleared and re-initialized."
        }
    }

    fun seedDemoData() {
        viewModelScope.launch {
            repository.seedDemoDataIfEmpty()
            _toastMessage.value = "Demo inventory and restock data seeded!"
        }
    }
}
