package com.example.data.repository

import androidx.room.withTransaction
import com.example.data.local.AppDatabase
import com.example.data.local.entity.AppSettingsEntity
import com.example.data.local.entity.DeliveryEntity
import com.example.data.local.entity.ProductEntity
import com.example.data.local.entity.SaleEntity
import com.example.data.local.entity.SaleItemEntity
import com.example.data.local.entity.SaleWithItems
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull

class PosRepository(private val database: AppDatabase) {
    private val productDao = database.productDao()
    private val saleDao = database.saleDao()
    private val deliveryDao = database.deliveryDao()
    private val appSettingsDao = database.appSettingsDao()

    val allProducts: Flow<List<ProductEntity>> = productDao.getAllProducts()
    val allSales: Flow<List<SaleWithItems>> = saleDao.getAllSalesWithItems()
    val allDeliveries: Flow<List<DeliveryEntity>> = deliveryDao.getAllDeliveries()
    val appSettings: Flow<AppSettingsEntity?> = appSettingsDao.getSettings()

    fun searchProducts(query: String): Flow<List<ProductEntity>> = productDao.searchProducts(query)

    suspend fun getProductById(id: Long): ProductEntity? = productDao.getProductById(id)

    suspend fun getProductByBarcode(barcode: String): ProductEntity? =
        productDao.getProductByBarcode(barcode.trim())

    suspend fun insertOrUpdateProduct(product: ProductEntity): Long {
        return if (product.id == 0L) {
            productDao.insertProduct(product)
        } else {
            productDao.updateProduct(product)
            product.id
        }
    }

    suspend fun deleteProduct(product: ProductEntity) {
        productDao.deleteProduct(product)
    }

    suspend fun checkoutSale(
        sale: SaleEntity,
        items: List<SaleItemEntity>
    ): Long {
        return database.withTransaction {
            val saleId = saleDao.insertSale(sale)
            val itemsWithSaleId = items.map { it.copy(saleId = saleId) }
            saleDao.insertSaleItems(itemsWithSaleId)

            // Decrement inventory stock
            items.forEach { item ->
                productDao.decreaseStock(item.productId, item.quantity)
            }
            saleId
        }
    }

    suspend fun logDelivery(
        delivery: DeliveryEntity,
        updatedProducts: List<Pair<Long, Int>> = emptyList() // Pair of productId to added quantity
    ): Long {
        return database.withTransaction {
            val deliveryId = deliveryDao.insertDelivery(delivery)
            updatedProducts.forEach { (productId, qtyAdded) ->
                productDao.increaseStock(productId, qtyAdded)
            }
            deliveryId
        }
    }

    suspend fun getSettingsDirect(): AppSettingsEntity {
        return appSettingsDao.getSettingsDirect() ?: AppSettingsEntity()
    }

    suspend fun saveSettings(settings: AppSettingsEntity) {
        appSettingsDao.insertOrUpdate(settings)
    }

    suspend fun getUnsyncedSales(): List<SaleWithItems> = saleDao.getUnsyncedSales()

    suspend fun getUnsyncedDeliveries(): List<DeliveryEntity> = deliveryDao.getUnsyncedDeliveries()

    suspend fun markSalesAsSynced(ids: List<Long>) = saleDao.markSalesAsSynced(ids)

    suspend fun markDeliveriesAsSynced(ids: List<Long>) = deliveryDao.markDeliveriesAsSynced(ids)

    suspend fun resetDatabase() {
        database.withTransaction {
            saleDao.deleteAllSaleItems()
            saleDao.deleteAllSales()
            deliveryDao.deleteAllDeliveries()
            productDao.deleteAllProducts()
            appSettingsDao.clearSettings()
            appSettingsDao.insertOrUpdate(AppSettingsEntity())
        }
    }

    suspend fun seedDemoDataIfEmpty() {
        val current = productDao.getAllProducts().firstOrNull()
        if (current.isNullOrEmpty()) {
            val demoProducts = listOf(
                ProductEntity(
                    name = "Arabica Premium Coffee 250g",
                    barcode = "8901234567890",
                    imagePath = null,
                    costPrice = 120.00,
                    retailPrice = 185.00,
                    stockQuantity = 24
                ),
                ProductEntity(
                    name = "Organic Green Tea 100g",
                    barcode = "8901234567891",
                    imagePath = null,
                    costPrice = 75.00,
                    retailPrice = 110.00,
                    stockQuantity = 18
                ),
                ProductEntity(
                    name = "Dark Chocolate Bar 70%",
                    barcode = "8901234567892",
                    imagePath = null,
                    costPrice = 55.00,
                    retailPrice = 90.00,
                    stockQuantity = 8 // Low stock alert!
                ),
                ProductEntity(
                    name = "Cold Brew Can 240ml",
                    barcode = "8901234567893",
                    imagePath = null,
                    costPrice = 45.00,
                    retailPrice = 75.00,
                    stockQuantity = 45
                ),
                ProductEntity(
                    name = "Almond Milk 1L",
                    barcode = "8901234567894",
                    imagePath = null,
                    costPrice = 110.00,
                    retailPrice = 160.00,
                    stockQuantity = 12
                ),
                ProductEntity(
                    name = "Honey Oat Cookies 150g",
                    barcode = "8901234567895",
                    imagePath = null,
                    costPrice = 60.00,
                    retailPrice = 95.00,
                    stockQuantity = 3 // Critical stock alert
                ),
                ProductEntity(
                    name = "Mineral Spring Water 500ml",
                    barcode = "8901234567896",
                    imagePath = null,
                    costPrice = 12.00,
                    retailPrice = 25.00,
                    stockQuantity = 60
                )
            )
            productDao.insertProducts(demoProducts)

            val existingSettings = appSettingsDao.getSettingsDirect()
            if (existingSettings == null) {
                appSettingsDao.insertOrUpdate(AppSettingsEntity())
            }

            // Seed initial restock delivery record for accounting
            val initialDelivery = DeliveryEntity(
                timestamp = System.currentTimeMillis() - 86400000L * 3,
                supplierName = "Highland Beverage Co.",
                totalCost = 3500.00,
                notes = "Initial shop opening inventory stock"
            )
            deliveryDao.insertDelivery(initialDelivery)
        }
    }
}
